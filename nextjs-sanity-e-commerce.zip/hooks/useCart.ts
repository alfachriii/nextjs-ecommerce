"use client";

import {
   addItemToCart,
   getItemsInCart,
   getProductsByIds,
} from "@/app/actions/cart";
import { ProductResult } from "@/sanity/types";
import { useStore } from "@/store";
import { useTransition } from "react";

export const useCart = () => {
   const { addItem, getGroupedItems } = useStore();
   const [isPending, startTransition] = useTransition();

   const handleAddItem = (product: ProductResult, quantity?: number) => {
      startTransition(async () => {
         try {
            const savedItemToDB = await addItemToCart(product?._id ?? "", quantity);
            // TODO: make toast for errors
            if (!savedItemToDB) return alert("Failed add item to card");

            // TODO: make success toast
            addItem(product);
            alert("Success Add Item To Cart");
         } catch (error) {
            alert(`Failed add item to cart: ${error}`);
         }
      });

   };

   const handleGetProductItems = () => {
      const currentProductItems = getGroupedItems();

      if (!(currentProductItems.length > 0)) {
         startTransition(async () => {
            try {
               const currentItems = await getItemsInCart();
               if (!currentItems) return;

               const productIds = currentItems.map((item) => item.productId);
               const products = await getProductsByIds(productIds);

               if (!products) return alert("Failed fetch products in cart");

               // TODO: handle this heavy loop
               products.map((product) => addItem(product));
               return;
            } catch (error) {
               return alert("Failed fetch products in cart");
            }
         });
      }


   };

   return {
      isPending,
      getGroupedItems,
      handleAddItem,
      handleGetProductItems
   };
};
